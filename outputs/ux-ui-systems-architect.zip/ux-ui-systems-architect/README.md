# Iris — Frontend UX/UI Systems Architect

Arquitecta de sistemas de front-end especializada en **aplicaciones mock-first**: audita
de extremo a extremo la arquitectura de información visual, repara la sincronización de
estado simulado, e implementa componentes canónicos de grado productivo a través del
flujo consultivo de **Webi.AI Elements**.

## 类型

Agent 型（单个 AI 专家）

## 功能

- **审计端到端视觉信息架构**：把每个指标、状态徽章、卡片、时间线与表格单元格回溯到
  其真实来源（store getter 或领域目录），产出「一致性矩阵」。
- **诊断 Mock 状态同步问题**：定位同一实体在不同屏幕渲染不一致的根因 —— 重复派生、
  陈旧快照、缓存指标在重水合后残留、种子数据不自洽、领域状态被本地镜像、时间分桶
  不一致。
- **修复（仅表现层）**：将内联派生替换为规范选择器，将硬编码文案替换为目录导入，
  让时间线按领域时间戳排序，为聚合补上正确的数据范围。
- **通过 Elements 顾问流程落地规范组件**：`ui_dsl → ui_requirement → ui_discovery →
  ui_refine → ui_implement`，并输出「组件区域 → 领域值 → store getter/目录项」映射表。
- **领域目录治理**：状态文案、颜色、排序与图标只有一处定义，杜绝跨模块词汇漂移。

## 使用示例

- 审计 Pedidos 模块的端到端视觉信息架构：指标、状态徽章、卡片、时间线和表格是否与
  MobX stores 完全一致，并列出不一致清单
- 把「订单详情」和「会话时间线」两块 UI 用 Elements 顾问流程重建成规范组件，并说明
  状态如何映射到 pedidos.store
- 检查我的 Mock 状态同步：为什么 Tableros 的指标数字和 Pedidos 列表对不上？给出根因
  和修复方案

## 包结构

```
ux-ui-systems-architect/
├── .codebuddy-plugin/plugin.json
├── agents/ux-ui-systems-architect.md          # 专家人格、信条、工作流
├── skills/visual-information-architecture/
│   ├── SKILL.md                               # 一致性矩阵、8 类缺陷、同步规则
│   └── references/
│       └── stockflow-project-ground-truth.md  # 项目实况：store 职责、已知缺陷模式
├── avatars/expert.png
└── README.md
```

## 头像

头像已自动生成在 `avatars/` 目录下。如需替换为自定义头像，要求：

- 格式：PNG（推荐）或 JPG
- 尺寸：512×512 px
- 大小：单张不超过 500KB

## 安装

专家包位于专家目录下：

```
C:\Users\Jessy\.workbuddy-ai\plugins\marketplaces\my-experts\plugins\ux-ui-systems-architect\
```

重新注册（使其在专家中心可见）：

```bash
python3 scripts/register_expert.py <expert-dir>
```

## 打包分享

```bash
python3 scripts/package_expert.py <expert-dir>
```
