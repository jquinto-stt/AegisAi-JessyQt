# StockFlow — Project Ground Truth

Reference card for the `ux-ui-systems-architect` expert. Read this before touching
any module. If the code contradicts this card, the code has drifted — report the drift
rather than silently following it.

---

## 1. Nature of the project

**A high-fidelity frontend-only mock. There is no backend, no API, no database, and no
server-side validation.** Do not introduce API clients, auth providers, network
layers, or server contracts. Everything the UI shows must originate from the
client-side reactive stores and their in-memory seeds.

| Aspect | Reality |
|---|---|
| Data origin | In-memory seeds + persisted client state |
| Persistence | Client-side storage, wrapped in try/catch (the storage API may be absent in non-browser environments) |
| Reactivity | Observable stores, components subscribe via an `observer` boundary |
| Auth / RBAC | Simulated in the client: roles, permissions and the active operator context all live in stores |
| Source of truth | **The stores. Not the components.** |

### Stack

React 18 · TypeScript · Vite · Tailwind CSS · MobX (`makeAutoObservable` + `observer`)
· client-side routing · vitest for tests.

### Repository layout caution

This workspace contains **two copies** of the application source: the authoritative one
tracked by git, and a stale nested snapshot that is git-ignored. **Always confirm the
path of the source you are auditing before reading or editing anything.** An analysis
performed on the stale copy produces findings that do not apply and can lead to
"fixes" that silently do nothing. Verify the target is the git-tracked tree.

---

## 2. Modules in scope

Four surfaces, one story. Every one of them must agree about the same order, the same
customer, and the same state.

| Module | What it shows |
|---|---|
| **Pedidos** | The order pipeline and its detail views |
| **Analítica** | Aggregate metrics and reporting |
| **Conversaciones / WhatsApp** | Messaging threads, customer identity, attention mode, unified timeline |
| **Tableros** | Dashboards and KPI cards |

### The order pipeline

```
nuevo → confirmado → en_preparacion → listo → en_camino → entregado
                                                         ↘ cancelado
```

This sequence is **the** domain vocabulary. Status labels, colours, badge variants,
stage ordering and progress indicators across all four modules derive from it. A
module that invents its own stage names is a **F7** defect (cross-module vocabulary
mismatch).

### The conversations domain

Threads carry a customer, a channel, an **attention mode** (automated/bot vs. human
operator), and a **unified timeline** that interleaves messages, order events and
status changes. The timeline is the highest-risk surface for **F6** (ordering/time
incoherence): entries must sort by their domain event timestamp, and the "latest
activity" shown on a thread list must be the same value the timeline's last entry
displays.

### The access domain

Roles, permissions (capability-style identifiers such as `orders.read`,
`channels.respond`) and the active operator context are store-backed. Two rules matter
for visual work:

- **Capability and scope are different questions.** A capability answers "may this
  operator perform this action?"; a data scope answers "which records may they see?".
  Never derive one from the other.
- **Scoping is a filter, not a permission.** A scoped screen showing global numbers is
  a **F8** defect (scope leak) — the aggregation must route through the scope-aware
  selector.

---

## 3. Store responsibilities (interface expectations)

Consult the actual store files for exact signatures; this table is the map of who owns
what, so findings cite the right owner.

| Store | Owns |
|---|---|
| **pedidos.store** | Orders, the pipeline state machine, transitions, order selectors |
| **conversaciones.store** | Threads, customers, attention mode, unified timeline |
| **session.store** | Active session, operator context, effective role |
| **operadores.store** | Operator records, roles and capabilities |

Rules that hold across all stores:

- **One write path per mutation.** Screens call actions; they never mutate domain
  objects or write derived fields.
- **Derived values are getters.** Counts, groupings, "active" lists, progress
  percentages and rollups are computed in the store, never in the component.
- **Persisted state is a projection.** Persist minimum domain data, recompute derived
  values on rehydration, and never persist a cached metric.
- **Rehydration must not fabricate.** Missing / corrupt / version-incompatible state
  falls back to a clean seed or empty state — never a partial merge.

---

## 4. Known defect patterns in this codebase

Check these first; they recur.

| Pattern | Where it shows up | Class |
|---|---|---|
| KPI card counts its own filtered array instead of reading the store's active-order getter | Tableros | F2 / F4 |
| A second screen independently counts the same list; the two counters drift | Analítica vs. Pedidos | F4 |
| Status label or colour written as a JSX literal instead of read from the pipeline catalogue | detail views, badges | F3 |
| Timeline entry order follows insertion, not event time | Conversaciones | F6 |
| "Last activity" on the thread list disagrees with the timeline's final entry | Conversaciones | F4 / F6 |
| Module-specific wording for the same pipeline state | any module | F7 |
| Aggregate shown on a scoped screen without applying the operator/channel scope | Tableros, Analítica | F8 |
| Seed fixture violates a domain invariant (e.g. a terminal state with no closing timestamp), producing holes in the timeline | seeds | F5 / F6 |

---

## 5. Verification protocol

A visual consistency fix is **not done** until the same value is shown to be read from
the same source in two independent surfaces. Acceptable evidence:

1. **Value table** — before/after values for each surface, plus the truth source cited.
2. **Test** — an assertion that the selector returns the value both surfaces render.
   Reuse the existing test setup and keep the existing suites green.
3. **Runtime inspection** — inspect the live store state and the rendered output
   together, when the change is presentation-only.

Also required: a check on the pre-existing test suites to confirm nothing regressed.

---

## 6. Toolchain map

### Design & components — the Elements advisory flow

| Tool | Use |
|---|---|
| `ui_dsl` | Load the DSL reference. **First, every session.** |
| `ui_requirement` | Requirement → structured spec + Design DSL |
| `ui_discovery` | Requirement → atomic component intents + catalog candidates |
| `ui_refine` | Once per intent: rank the best catalog match, with rationale |
| `ui_implement` | Select, accumulate, package the bundle |
| `ui_lookup` | Existence / exact-name lookup only — never a way to build a screen |
| `ui_scaffolding` | Base app shell / layouts for a new foundation |

**Catalog-only doctrine.** Every UI component comes from the catalog, selected through
the flow. Never hand-write a component the catalog could provide, never import a
third-party UI library, never invent a component name. If the catalog cannot express a
requirement, say so and propose the closest catalog-native alternative — that is the
user's decision, not a gap to fill with hand-written code.

**The flow order is fixed:** `ui_dsl` → `ui_requirement` → `ui_discovery` →
`ui_refine` (once per intent) → `ui_implement`. No skipping or reordering. The Design
DSL is reproduced verbatim for the user whenever it exists or changes.

### Project context — the devtools toolkit

| Tool | Use |
|---|---|
| `echo` | Connectivity / latency check |
| `discovery` | Session entry point: usage guide and active capabilities |
| `projects` | Discover and map absolute project / module paths |
| `search` | Semantic search over the code index — the fast way to find a component, function or type |
| `runtime` | Inspect execution environment, active state and logs |
| `kiro_steerings` | Architecture and governance directives for the project |
| `read_image` | Read screenshots / mockups as visual input |
| `shared_resources` | Shared resources across monorepo packages |
| `pulumi_state` | Declarative infrastructure state, when applicable |

---

## 7. Boundaries

- **Presentation layer only.** No changes to the domain contract, the store's public
  API, or business rules in service of a visual fix.
- **No backend.** Do not propose a service to fix an inconsistency; fix the consumer
  or add a selector.
- **Hide what cannot be done; explain what is disabled.** Where an action is not
  permitted, prefer hiding it; where hiding would mislead (a settings surface the
  operator can read), disable it with a stated reason.
- **Never fabricate a plausible value.** An unknown state renders as unknown.
