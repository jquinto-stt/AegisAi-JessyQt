---
name: visual-information-architecture
description: "Audit and repair end-to-end visual information architecture in a mock-first frontend. Use when the user reports that numbers, status badges, cards, timelines, tables or dashboards disagree with each other or with the reactive stores; when a metric shown in one module does not match the same metric in another; or when a screen needs to be rebuilt as a canonical component with a state-to-store mapping. Covers the consistency matrix, mock state synchronization rules, and the canonical component pipeline."
---

# Visual Information Architecture — Audit & Repair

A repeatable workflow for making a mock-first frontend show **one coherent story** on every screen.

The failure mode this skill exists to fix: the app has a correct data model, but the
**presentation layer re-derives truth** — counting orders in a dashboard instead of
reading the store's selector, hardcoding a status label, computing a "pending" badge
from a timestamp instead of from the pipeline state. The result is a UI that is
internally contradictory: the inbox says 12 open orders, the dashboard says 9, the
customer card says 11.

---

## Core Doctrine

1. **The store is the only source of truth.** Every number, label, badge and colour
   rendered on screen must resolve to a value produced by a store getter/selector or
   to a literal from a domain catalog. If a component computes a business value
   inline, that is the defect.
2. **Derive, never duplicate.** A metric that appears on two screens must be read from
   **one** selector. Two independent `filter().length` calls that happen to agree today
   are a latent inconsistency, not a correct implementation.
3. **Catalogues own vocabulary.** Status labels, status colours, stage ordering and
   iconography live in a single catalogue (a `*.constants.ts`-style module), imported
   by every consumer. Inline string literals like `"En preparación"` are defects.
4. **Status is data, not date.** A badge must be driven by the domain state field, not
   inferred from timestamps, message recency, or array position.
5. **Presentation-only repair.** When fixing visual inconsistencies, never change the
   store's public contract or the business rules. Fix the *consumer*.
6. **Fail closed.** Where information is genuinely absent, render an explicit empty /
   unknown state. Never substitute a plausible-looking default, because in a mock the
   default becomes indistinguishable from real data.

---

## The Consistency Matrix

For every metric, badge, card, timeline entry and table column in scope, complete one
row. This matrix *is* the audit deliverable.

| # | Surface (screen / component) | Rendered element | Displayed value | Truth source (store getter / catalogue) | Verdict | Defect class |
|---|---|---|---|---|---|---|
| 1 | Tableros → KPI "Pedidos activos" | metric card | `9` | `pedidosStore.activos.length` | ❌ | F2 derived-inline |
| 2 | Pedidos → lista header | counter badge | `12` | `pedidosStore.activos.length` | ✅ | — |
| 3 | Conversaciones → hilo | status chip | `"En preparación"` | literal in JSX | ❌ | F3 hardcoded-label |

### Defect classes

| Class | Name | Signature | Typical fix |
|---|---|---|---|
| **F1** | **Orphan value** | A number/label with no store backing at all — a literal that looks like data | Bind to the correct selector; if no selector exists, add one **in the store**, not in the component |
| **F2** | **Derived inline** | The component recomputes a business value (`filter`, `reduce`, date math) instead of consuming a selector | Extract to a store getter; replace all call sites with it |
| **F3** | **Hardcoded vocabulary** | Status text, colour, or icon written as a literal in JSX | Move to the domain catalogue; import it |
| **F4** | **Split truth** | Two surfaces derive the same metric independently and can diverge | Collapse onto a single selector |
| **F5** | **Stale snapshot** | Value captured once (module-level constant, `useState` initialiser, non-reactive read) so it does not follow store updates | Read reactively (`observer` / store-derived value in render) |
| **F6** | **Ordering/time incoherence** | Timeline entries sorted by insertion instead of by event time; "most recent" derived from array position | Sort by the domain timestamp field; keep the comparator in one place |
| **F7** | **Cross-module vocabulary mismatch** | The same domain state is named differently in two modules | Adopt the canonical catalogue term everywhere |
| **F8** | **Scope leak** | Aggregation ignores a scope boundary (per-operator / per-channel / per-queue), so a scoped screen shows global numbers | Route through the scope-aware selector |

### Reporting format

Findings are reported **most severe first**, and each row must carry the exact file
path and line reference of both the defect and the truth source. A finding without a
truth-source citation is not actionable and must not be reported.

---

## Mock State Synchronization Rules

A mock frontend has no server to reconcile state. These rules keep the in-memory and
persisted views of the same entity from drifting apart.

### Rule 1 — Single write path per mutation
Every state transition has exactly one store action. Screens never mutate domain
objects directly, and never write a derived field — derived fields are always getters.

### Rule 2 — Persisted state is a projection, not a second source
If state is persisted (e.g. to `localStorage`), persist the **minimum domain data** and
recompute all derived values on rehydration. Persisting a cached metric is how a stale
number survives a reload and then contradicts the live list.

### Rule 3 — Mutation fan-out must be explicit
When one entity's transition changes another entity's presentation (an order moving to
`entregado` removing an entry from a channel's pending list), the fan-out belongs in a
documented place. Scattered side effects in components produce screens that update at
different times.

### Rule 4 — Rehydration must not fabricate
If persisted state is missing, corrupt, or version-incompatible, fall back to a clean
seed or an empty state. Never partially merge a stale shape onto a new one — that is
the classic source of "the badge says one thing and the card says another".

### Rule 5 — Seeds must be internally consistent
Fixture/seed data must satisfy the invariants the UI asserts. If a seed has an order in
`entregado` with no delivery timestamp, the timeline will render a hole and every screen
will disagree about whether the order is complete. Validate seeds against the domain
invariants before shipping them.

### Rule 6 — No UI-local state that shadows domain state
A component must not hold a `useState` mirror of a domain field (a locally-edited copy
of the status, a locally-counted total). Local state is only for view-only concerns
(open/closed, filter text, scroll position).

### Rule 7 — Determinism
Time-dependent rendering (relative timestamps, "today" buckets) must read from one
injectable clock so snapshots and tests are reproducible and two screens cannot bucket
the same event into different days.

---

## Canonical Component Pipeline

When a repaired surface should become a reusable component, it goes through the
Elements advisory flow — **never hand-written**.

1. `ui_dsl` — load the DSL reference first; do not work from remembered syntax.
2. `ui_requirement` — describe the component with its **real data shape** and all
   states it must express (loading, empty, error, populated, disabled, and every
   domain status variant it displays).
3. `ui_discovery` — decompose into atomic component intents.
4. `ui_refine` — once per intent, rank the catalog candidates and record the rationale.
5. `ui_implement` — package the selection into the bundle.

Then produce the **state→store mapping** for the component:

| Component region | Catalog component | Domain value bound | Store getter / catalogue entry | States rendered |
|---|---|---|---|---|
| Status chip | (catalog component) | `pedido.estado` | `ESTADOS_PEDIDO[estado].label` | all pipeline states |
| Counter | (catalog component) | active order count | `pedidosStore.activosCount` | 0 / n |

A canonical component is not finished until every region its table lists resolves to a
named store getter or a named catalogue entry. Any region that cannot be resolved is an
open question, not a licence to compute inline.

---

## Deliverables

### Audit
1. **Consistency matrix** — every surface × element × truth source × verdict.
2. **Findings list** — ordered by severity, each with defect class, exact file
   reference, and the cited truth source.
3. **Root-cause clusters** — group findings by defect class; a single missing selector
   usually explains a dozen rows.

### Repair
4. **Fix plan** — per finding: file, change, and why it does not alter the domain
   contract.
5. **Verification evidence** — the concrete check that two surfaces now read the same
   value (test, runtime inspection, or a before/after value table).
6. **State→store mapping** — for each canonical component produced.

---

## Notes on judgement

- Prefer one correct selector over many correct-looking call sites. The second
  derivation is the bug, even when it currently agrees.
- When a surface needs a value no selector provides, add the selector. Do not "temporarily"
  compute it in the view — in a mock, temporary code is permanent code.
- Verification is not optional: a consistency fix is only done when two independent
  surfaces are shown reading the same value.
